### Hexlet tests and linter status:
[![Actions Status](https://github.com/EugeneAnisimov97/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/EugeneAnisimov97/python-project-49/actions)
<a href="https://codeclimate.com/github/EugeneAnisimov97/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/8f62247e011b5d948ddd/maintainability" /></a>

<a href="https://asciinema.org/a/ffNE0MFoImME8LQ2iOgUtE09k" target="_blank"><img src="https://asciinema.org/a/ffNE0MFoImME8LQ2iOgUtE09k.svg" /></a>

<a href="https://asciinema.org/a/Xfj8c0Yj2Gdpqt9EAHUnzZBsO" target="_blank"><img src="https://asciinema.org/a/Xfj8c0Yj2Gdpqt9EAHUnzZBsO.svg" /></a>

<a href="https://asciinema.org/a/80ZcGewKeczeSRKLWgxvNDnEF" target="_blank"><img src="https://asciinema.org/a/80ZcGewKeczeSRKLWgxvNDnEF.svg" /></a>

<a href="https://asciinema.org/a/MyxLIwlW0N2krC3181lGure3f" target="_blank"><img src="https://asciinema.org/a/MyxLIwlW0N2krC3181lGure3f.svg" /></a>